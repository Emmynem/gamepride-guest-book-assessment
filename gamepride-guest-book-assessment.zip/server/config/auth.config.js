export const secret = "guest-2&27-book^%232-key";
export const password_options = {
    minLength: 8,
    minLowercase: 1,
    minNumbers: 1,
    minSymbols: 1,
    minUppercase: 1
};